package altsrc

//go:generate python ../generate-flag-types altsrc -i ../flag-types.json -o flag_generated.go
