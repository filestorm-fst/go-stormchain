# keycard-go

`keycard-go` is a set of Go packages built to interact with the [Status Keycard](https://github.com/status-im/status-keycard).

If you only need a tool to initialize your card, check out the [keycard](cmd/keycard) CLI.
