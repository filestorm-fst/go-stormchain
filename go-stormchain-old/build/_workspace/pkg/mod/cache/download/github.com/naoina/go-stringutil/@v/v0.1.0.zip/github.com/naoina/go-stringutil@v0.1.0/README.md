# stringutil [![Build Status](https://travis-ci.org/naoina/go-stringutil.svg?branch=master)](https://travis-ci.org/naoina/go-stringutil)

## Installation

    go get -u github.com/naoina/go-stringutil

## Documentation

See https://godoc.org/github.com/naoina/go-stringutil

## License

MIT
